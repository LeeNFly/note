/*
	只要是数据发生改变，那么页面中的所有指令和表达式都会被重新计算一次（事件除外，事件只会在触发的时候才会执行）
*/

// eslint-disable-next-line
const vm = new Vue({
  el: '#app',
  data: {
    // 任务名称
    todoName: '',
    editId: -1,
    // 任务列表
    todos: [
      { id: 1, name: '抽烟', completed: false },
      { id: 2, name: '喝酒', completed: true },
      { id: 3, name: '烫头发', completed: true }
    ]
  },

  methods: {
    // 添加任务
    add() {
      /*
				1.1 添加完成后，清空文本框
				1.2 id 要计算出来，而不是写死
				1.3 非空值判断
			*/
      if (this.todoName.trim() === '') {
        return
      }

      let id =
				this.todos.length === 0 ? 1 : this.todos[this.todos.length - 1].id + 1

      // if (this.todos.length === 0) {
      //   id = 1
      // } else {
      //   id = this.todos[this.todos.length - 1].id + 1
      // }

      this.todos.push({
        id,
        name: this.todoName,
        completed: false
      })

      this.todoName = ''
    },

    // 删除任务
    delTodo(index) {
      // console.log('del', index)
      // 根据index删除数组元素
      this.todos.splice(index, 1)
    },

    showEditStatus(id) {
      this.editId = id
    },

    updateTodo() {
      this.editId = -1
    }
  },

  // 计算属性
  computed: {
    showFooter() {
      return this.todos.length > 0
    }
  }
})
