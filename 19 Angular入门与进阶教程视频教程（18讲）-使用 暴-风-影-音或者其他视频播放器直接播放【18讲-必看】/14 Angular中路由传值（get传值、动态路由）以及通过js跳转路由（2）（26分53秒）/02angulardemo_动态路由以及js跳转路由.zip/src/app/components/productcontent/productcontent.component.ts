import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productcontent',
  templateUrl: './productcontent.component.html',
  styleUrls: ['./productcontent.component.scss']
})
export class ProductcontentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
